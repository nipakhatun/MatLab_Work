[~, ~,ctg] = xlsread('Datasheeet','Sheet1'); 
data = cell2mat(ctg(1:end, 1:end));
data1=data(:,1);
data2=data(:,2);
disp(data1);
n=length(data1);
disp(n);
sum1=0;
sum2=0; 
%mean=mean2(data);
for i=1:length(data1)
    if data(i)==-1
        disp(i);
    
    else
        sum1=sum1+data1(i);
end
    
end
mean1=round(sum1/22);
fprintf('mean of allelectronics:%f\n',mean1);
%disp(mean1);

for i=1:length(data2)
    if data2(i)==-1
        disp(i);
    
    else
        sum2=sum2+data2(i);
    end
end
mean2=round(sum2/22);

fprintf('mean of allelectronics:%f\n',mean2);


data(4,1)=mean1;
data(4,2)=mean2;
data(9,1)=mean1;
data(9,2)=mean2;
fprintf('After Filling the Missing Values:\n\n');
disp(data);
data=sort(data);


new_data1=data(:,1)
new_data2=data(:,2)
for i=1:6
    EBin1(i,1)=new_data1(i,1);
    EBin2(i,1)=new_data1(i+6,1);
    EBin3(i,1)=new_data1(i+12,1);
    EBin4(i,1)=new_data1(i+18,1);
end
for i=1:6
  HBin1(i,1)=new_data2(i,1);
  HBin2(i,1)=new_data2(i+6,1);
  HBin3(i,1)=new_data2(i+12,1);
  HBin4(i,1)=new_data2(i+18,1);
end




for i=2:5
    if( EBin1(i)-EBin1(1))<=(EBin1(i)-EBin1(6))
        EBin1(i)=EBin1(1);
    else
        EBin1(i)=EBin1(6);
    end
    if( EBin2(i)- EBin2(1))<=( EBin2(i)- EBin2(6))
        EBin2(i)= EBin2(1);
    else
        EBin2(i)= EBin2(6);
    end
    if( EBin3(i)-EBin3(1))<=(EBin3(i)-EBin3(6))
        EBin3(i)=EBin3(1);
    else
      EBin3(i)=EBin3(6);
    end
    if( EBin4(i)-EBin4(1))<=(EBin4(i)-EBin4(6))
        EBin4(i)=EBin4(1);
    else
      EBin4(i)=EBin4(6);
    end
    
end

AllElectronics_data(1:6)=EBin1;
AllElectronics_data(7:12)=EBin2;
AllElectronics_data(13:18)=EBin3;
AllElectronics_data(19:24)=EBin4;
fprintf('AllElectronics_data\n\n');
disp(AllElectronics_data);
    
for i=2:5
    if( HBin1(i)-HBin1(1))<=(HBin1(i)-HBin1(6))
       HBin1(i)=HBin1(1);
    else
        HBin1(i)=HBin1(6);
    end
    if( HBin2(i)- HBin2(1))<=( HBin2(i)- HBin2(6))
       HBin2(i)= HBin2(1);
    else
         HBin2(i)=  HBin2(6);
    end
    if(  HBin3(i)- HBin3(1))<=( HBin3(i)- HBin3(6))
         HBin3(i)= HBin3(1);
    else
       HBin3(i)=EBin3(6);
    end
    if(  HBin4(i)- HBin4(1))<=( HBin4(i)- HBin4(6))
         HBin4(i)= HBin4(1);
    else
       HBin4(i)= HBin4(6);
    end
    
end
disp(HBin1);
HighTech_data(1:6)=HBin1;
HighTech_data(7:12)=HBin2;
HighTech_data(13:18)=HBin3;
HighTech_data(19:24)=HBin4;

fprintf('HighTech_data\n\n');
disp(HighTech_data);

result=0;
for i=1:24
    result=result+(new_data1(i)*new_data2(i));
end
fprintf('The Summation of AllElectronics_data and HighTech_data  : %f\n\n',result);

%disp(result);
standard_deviation1=std2(new_data1);
standard_deviation2=std2(new_data2);
fprintf('The Standard Deviation: %f %f\n\n',standard_deviation1,standard_deviation2);

sum1=0;
sum2=0;
for i=1:n
    sum1=sum1+new_data1(i);
end
for i=1:24
    sum2=sum2+new_data2(i);
end

Mean1=sum1/24
Mean2=sum2/24
fprintf('The Mean: %f %f\n\n',Mean1,Mean2);

Correlation=(result-(24*Mean1*Mean2))/(23*standard_deviation1*standard_deviation2);

 fprintf('The Correlation Co-efficient: %f\n\n',Correlation);

if(Correlation > 0)
    fprintf('The price of all items of the organizations are positively correlated.\n\n');
else if(Correlation < 0)
        fprintf('The price of all items of the organizations are negatively correlated.\n\n');
else
   fprintf('The price of all items of the organizations are independent.\n\n');  
    end
end

