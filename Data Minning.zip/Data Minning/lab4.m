function varargout = lab4(varargin)
% LAB4 MATLAB code for lab4.fig
%      LAB4, by itself, creates a new LAB4 or raises the existing
%      singleton*.
%
%      H = LAB4 returns the handle to a new LAB4 or the handle to
%      the existing singleton*.
%
%      LAB4('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LAB4.M with the given input arguments.
%
%      LAB4('Property','Value',...) creates a new LAB4 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before lab4_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to lab4_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help lab4

% Last Modified by GUIDE v2.5 19-Oct-2017 12:15:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @lab4_OpeningFcn, ...
                   'gui_OutputFcn',  @lab4_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before lab4 is made visible.
function lab4_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to lab4 (see VARARGIN)

% Choose default command line output for lab4
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes lab4 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = lab4_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
folder_name = uigetdir(pwd, 'Select the directory of images');
if ( folder_name ~= 0 )
    handles.folder_name = folder_name;
    guidata(hObject, handles);
else
    return;
end

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
jpgImagesDir = fullfile(handles.folder_name, '*.jpg');
num_of_jpg_images = numel( dir(jpgImagesDir) );
totalImages = num_of_jpg_images;
jpg_files = dir(jpgImagesDir);
if ( ~isempty( jpg_files ))
    jpg_counter = 0;
    for k = 1:totalImages
        if ( (num_of_jpg_images - jpg_counter) > 0)
            imgInfoJPG = imfinfo( fullfile( handles.folder_name, jpg_files(jpg_counter+1).name ) );
            if ( strcmp( lower(imgInfoJPG.Format), 'jpg') == 1 )
                sprintf('%s \n', jpg_files(jpg_counter+1).name)
                I = imread( fullfile( handles.folder_name, jpg_files(jpg_counter+1).name ) );
                [pathstr, name, ext] = fileparts( fullfile( handles.folder_name, jpg_files(jpg_counter+1).name ) );
                I= imresize(I, [384 256]);
                disp(ext);
               
            end
            jpg_counter = jpg_counter + 1;
        end
          %channel divide
                RedChannel=I(:,:,1);
                GreenChannel=I(:,:,2);
                BlueChannel=I(:,:,3);
                 %Mean
                Rmean = double(mean2(RedChannel));
                Gmean = double(mean2(GreenChannel));
                Bmean = double(mean2(BlueChannel));
                %Mode
                Rs = double(std2(RedChannel));
                Gs =double(std2(GreenChannel));
                Bs = double(std2(BlueChannel));
                %IQR
%                  riqr=double(iqr(RedChannel(:)))
%               giqr=double(iqr(GreenChannel(:)))
%               biqr=double(iqr(BlueChannel(:)))
                dataset(k,:) = [Rmean Gmean Bmean  Rs Gs  Bs ]; 
                
           clear('image', 'img', 'hsvHist', 'autoCorrelogram', 'color_moments', ...
            'gabor_wavelet', 'wavelet_moments', 'set', 'imgInfoJPG', 'imgInfoPNG', ...
            'imgInfoGIF');
    end
    uisave('dataset', 'dataset1');
    clear('dataset', 'jpg_counter', 'png_counter', 'bmp_counter');
end

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[query_fname, query_pathname] = uigetfile('*.jpg; *.png; *.bmp', 'Select query image');
if (query_fname ~= 0)
    query_fullpath = strcat(query_pathname, query_fname);
    [pathstr, name, ext] = fileparts(query_fullpath); % fiparts returns char type
    if ( strcmp(lower(ext), '.jpg') == 1 || strcmp(lower(ext), '.png') == 1 ...
            || strcmp(lower(ext), '.bmp') == 1 )
        Test_Image = imread( fullfile( pathstr, strcat(name, ext) ) );
        Test_Image= imresize(Test_Image, [384 256]);
        R=Test_Image(:,:,1);
        G=Test_Image(:,:,2);
        B=Test_Image(:,:,3);
        Rmean =double( mean2(R));
        Gmean = double(mean2(G));
        Bmean = double(mean2(B));

        Rs = double(std2(R));
        Gs =double( std2(G));
        Bs = double(std2(B));
        queryImageFeature = [Rmean Gmean Bmean  Rs Gs  Bs ];
        handles.queryImageFeature = queryImageFeature;
        guidata(hObject, handles);
       
    else
        errordlg('You have not selected the correct file type');
    end
else
    return;
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, ~, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
data_set=load ('dataset1.mat');

label=[1; 1 ;1; 1; 1; 2; 2; 2; 2; 2]
 p = fitctree(data_set.dataset,label);
 %c=data_set.dataset;
 view(p);
 c=handles.queryImageFeature;
 t=predict(p,c);
 disp(t);
 if  t == 1
    R1 = 'Late Blight';
    disp('Late Blight ');  
   
 
    
 
elseif t == 2
    R7 = 'Early Blight';
    
    disp('Early Blight ');  
  
    

else
    R7 = 'Flower';
    
    set(handles.result,'string',R7);
    
   
    
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
