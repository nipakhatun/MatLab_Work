f1=imread('im1.jpg');
f2=imread('im2.jpg');
f3=imread('im3.jpg');
f1_r300=f1(:,:,1);
f1_g300=f1(:,:,2);
f1_b300=f1(:,:,3);

f2_r301=f2(:,:,1);
f2_g301=f2(:,:,2);
f2_b301=f2(:,:,3);

f3_r=f3(:,:,1);
f3_g=f3(:,:,2);
f3_b=f3(:,:,3);
mean1_r=mean2(f1_r300);
disp(mean1_r);
mean1_g=mean2(f1_g300);
disp(mean1_g);

mean1_b=mean2(f1_b300);
disp(mean1_b);


mean2_r=mean2(f2_r301);
mean2_g=mean2(f2_g301);
mean2_b=mean2(f2_b301);

mean3_r=mean2(f3_r);
mean3_g=mean2(f3_g);
mean3_b=mean2(f3_b);

stad1_r=std2(f1_r300);
disp(stad1_r);
stad1_g=std2(f1_g300);
disp(stad1_g);
stad1_b=std2(f1_b300);
disp(stad1_b);

stad2_r=std2(f2_r301);
disp(stad2_r);
stad2_g=std2(f2_b301);
disp(stad2_g);
stad2_b=std2(f2_b301);
disp(stad2_b);

stad3_r=std2(f3_r);
stad3_g=std2(f3_g);
stad3_b=std2(f3_b);


d1=sqrt((mean1_r-mean2_r)^2+(stad1_r-stad2_r)^2+(mean1_g-mean2_g)^2+(stad1_g-stad2_g)^2 +(mean1_b-mean2_b)^2+(stad1_b-stad2_b)^2);
disp(d1);
d2=sqrt((mean1_r-mean3_r)^2+(stad1_r-stad3_r)^2+(mean1_g-mean3_g)^2+(stad1_g-stad3_g)^2 +(mean1_b-mean3_b)^2+(stad1_b-stad3_b)^2);
disp(d2);
d3=sqrt((mean2_r-mean3_r)^2+(stad2_r-stad3_r)^2+(mean2_g-mean3_g)^2+(stad2_g-stad3_g)^2 +(mean2_b-mean3_b)^2)+(stad2_b-stad3_b)^2;
disp(d3);

if d1<d2 &&d1<d3
    sm1=d1;
else if d2<d1 && d2<d3
        sm1=d2;
    else
        sm1=d3
    end
end

disp(sm1);

a=zeros(3,3);
a(2,1)=d1;
a(3,1)=d2;
a(3,2)=d3;




for i=1:3
    for j=1:3
       if (a(i,j)==sm1)
           p=i;
           q=j;
       
       end
    end
end



fprintf('similar image %d &%d',p,q);





    









   