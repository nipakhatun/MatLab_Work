 % Number of image in folder and le
 features = zeros(15,10); 
 image_files = dir('image/*.jpg');
for k=1:numel(image_files)
   currentImg_name = image_files(k).name;
   imageName = strsplit(currentImg_name,'.');
   disp(imageName);
   currentImagePath = strcat('image/',currentImg_name);
   I = imread(currentImagePath);
  
   %chanel separation
   red_chnel=double(I(:,:,1));
   green_chnel=double(I(:,:,2));
   blue_chnel=double(I(:,:,3));
   
   %mean
   name = str2num(imageName{1});
   redMean = mean2(red_chnel(:));
   greenMean = mean2(green_chnel(:));
  blueMean = mean2(blue_chnel(:));
   
   
   %mid rang
   redMid_rang=(max(red_chnel(:))+min(red_chnel(:)))/2;
   greenMid_rang=(max(green_chnel(:))+min(green_chnel(:)))/2;
    blueMid_rang=(max(blue_chnel(:))+min(blue_chnel(:)))/2;
  
   
   %Mode
   red_mode=mode(red_chnel(:));
   green_mode=mode(green_chnel(:));
   blue_mode=mode(blue_chnel(:));
   
   
   
   features(k,:) = [redMean greenMean blueMean redMid_rang greenMid_rang blueMid_rang red_mode green_mode blue_mode name]; 
end

image_Names= features(:, end);
features(:, end) = [];
%disp(size(imageNames));


Q = imread('im1.jpg');
red_chnel=double(Q(:,:,1));
green_chnel=double(Q(:,:,2));
blue_chnel=double(Q(:,:,3));

redMean = mean2(red_chnel(:));
greenMean = mean2(green_chnel(:));
blueMean= mean2(blue_chnel(:));



redMid_rang=(max(red_chnel(:))+min(red_chnel(:)))/2;
greenMid_rang=(max(green_chnel(:))+min(green_chnel(:)))/2;
blueMid_rang=(max(blue_chnel(:))+min(blue_chnel(:)))/2;


%MOde
red_mode=mode(red_chnel(:));
green_mode=mode(green_chnel(:));
blue_mode=mode(blue_chnel(:));
   

   
Query_features =zeros(1,9); 

Query_features = [redMean greenMean blueMean redMid_rang greenMid_rang blueMid_rang red_mode green_mode blue_mode];
euclidean = zeros(15,1);
for k = 1:15
    euclidean(k) = sqrt( sum( power( features(k, :) - Query_features, 2 ) ) );  
end
%disp(euclidean);
euclidean = [euclidean image_Names];

% sort euclidean distance according to smallest value
[sortEuclidDist index] = sortrows(euclidean);
sortedEuclidImgs = sortEuclidDist(:, 2);

%Display Similar image name
 figure
fprintf('Using Euclidean distance:\n');
for k = 1:5
    img_name = sortedEuclidImgs(k);
    img_name = int2str(img_name);
    disp(img_name);
    str_img_name = strcat('images\', img_name, '.jpg');
    returned_img = imread(str_img_name);
    subplot(3, 2, k+1);
    imshow(returned_img, []);
    
    
end

supremum = zeros(15,1);
for k = 1:15
    supremum(k) = max( abs(( features(k, :) - Query_features )) );  
end
%disp(supremum);
supremum = [supremum image_Names];
[sort_supremumdist index] = sortrows(supremum);
sort_supremumImgs = sort_supremumdist(:, 2);

 fprintf('Using Supremum distance:\n');

figure
for k = 1:5
    img_name = sort_supremumImgs(k);
    img_name = int2str(img_name);
    disp(img_name);
     str_img_name = strcat('images\', img_name, '.jpg');
    returned_img = imread(str_img_name);
    subplot(3, 2, k+1);
    imshow(returned_img, []);
   
end














