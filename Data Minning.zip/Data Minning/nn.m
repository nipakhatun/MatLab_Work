[~, ~,ctg] = xlsread('dataset','Sheet1'); 
pricelist = cell2mat(ctg(1:end));
n=length(pricelist);
disp(pricelist);
disp(n);

fprintf('Please give the binwidth=');
w= input('');
histogram(pricelist,'Binwidth',w); 



sum=0;
for i=1:n
    sum=sum+pricelist(i);
end
Mean=sum/n;
fprintf('Mean=%f\n',Mean);

Std=std(pricelist);
fprintf('Standard Devation=%f\n',Std);


%Min_max Normalization

MinA=min(pricelist);
MaxA=max(pricelist);

fprintf('Min value=%f\n',MinA);
fprintf('Max value=%f\n',MaxA);

New_Min=0;
New_Max=1;
fprintf('Min-max normalization: \n\n ');
value=(New_Max-New_Min);
for i=1:n
   v=((( pricelist(i)-MinA)/(MaxA-MinA))*value)+New_Min;
   disp(v);
   %disp(pricelist(i));
end

%Z_score Normalization
fprintf('z-score normalization using standard deviation:\n\n  ');
for i=1:n
    v1=(pricelist(i)-Mean)/Std;
    disp(v1);
end

%2nd rule for Z-score
sum1=0;
for i=1:n
    sum1=sum1+(abs(pricelist(i)-Mean));
end
sA=sum1/n;
disp(sA);
fprintf('z-score normalization using the mean absolute deviation:\n\n');
for i=1:n
    v2=(pricelist(i)-Mean)/sA;
    disp(v2);
end

%x = inputdlg('Please give the input j=:');
fprintf('Please give the input j=');
j = input('');

fprintf('decimal scaling:\n \n');
for i=1:n
    v=(pricelist(i))/10.^j;
   disp(v);
end


