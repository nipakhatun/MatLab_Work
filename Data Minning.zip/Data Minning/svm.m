function [result] = svm(T,C,Test)

u=unique(C);
numClasses=length(u);
result = zeros(length(Test(:,1)),1);

for k=1:numClasses
    G1vAll=(C==u(k));
    temp(k) = svmtrain(T,G1vAll);
end

for j=1:size(Test,1)
    for k=1:numClasses
        if(svmclassify(temp(k),Test(j,:))) 
            break;
        end
    end
    result(j) = k;
end